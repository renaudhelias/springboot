package fr.renaud;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import junit.framework.TestCase;

@RunWith(SpringRunner.class)
@TestPropertySource(locations = "classpath:application-test.properties")
@DataJpaTest
public class PoireDAOTest extends TestCase {

	@Autowired
    private TestEntityManager entityManager;
	
	@Before
	public void init() {
		Poire p = new Poire();
		p.setSaison("test");
		entityManager.persist(p);
	    entityManager.flush();
	}

	@Autowired
	private PoireDAO poireDAO;
	
	@Test
	public void testFindAll() {
		List<Poire> poires = poireDAO.findAll();
		assertEquals(1, poires.size());
		assertEquals("test", poires.get(0).getSaison());
	}
	
	@Test
	public void testGetOne() {
		Poire poire = poireDAO.getOne(2l);
		assertEquals("test", poire.getSaison());
	}

}
