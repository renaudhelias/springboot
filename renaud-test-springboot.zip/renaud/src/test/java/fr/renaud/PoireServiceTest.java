package fr.renaud;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;

import junit.framework.TestCase;


@RunWith(SpringRunner.class)
@TestPropertySource(locations = "classpath:application-test.properties")
@DataJpaTest
public class PoireServiceTest extends TestCase {

	@TestConfiguration
    static class PoireServiceImplTestContextConfiguration {
 
        @Bean
        public PoireService employeeService() {
            return new PoireService();
        }
    }
 
	
	@Autowired
	private TestEntityManager entityManager;
	
	@Autowired
	PoireService poireService;
	
	@Before
	public void init() {
		Poire p = new Poire();
		p.setSaison("test");
		entityManager.persist(p);
	    entityManager.flush();
	}
	@Test
	public void testFindAll() {
		List<String> poires = poireService.findAll();
		assertEquals(1l,poires.size());
		assertEquals("test",poires.get(0));
	}
	@Test
	public void testFindPoireById() {
		PoireDTO poire = poireService.findPoireById(2l);
		assertEquals(2l,poire.getId());
		assertEquals("test",poire.getSaison());
	}
	@Test
	public void testGetAllPoires() {
		List<PoireDTO> poires = poireService.getAllPoires();
		assertEquals(1,poires.size());
		assertEquals("test",poires.get(0).getSaison());
	}

}
