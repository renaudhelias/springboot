package fr.renaud;

import java.util.List;

public interface IPoireService {
	List<String> findAll();
	public PoireDTO findPoireById(Long poireId);
	public List<PoireDTO> getAllPoires();
}
