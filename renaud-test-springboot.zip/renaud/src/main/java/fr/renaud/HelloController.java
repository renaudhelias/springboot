package fr.renaud;

import org.springframework.web.bind.annotation.RestController;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@RestController
// marche pas avec les GetMapping ça.
@RequestMapping("/arbre/*")
public class HelloController {

    private static final Logger logger = LoggerFactory.getLogger(HelloController.class);
	
    @Autowired
    @Qualifier("poireService")
    IPoireService poireService;
    
	@RequestMapping("/BABA")
	public String index() {
		return "Greetings from Spring Boot!";
	}

//Web server failed to start. Port 8080 was already in use.	
//	@RequestMapping("/poire")
//	public String poire() {
//		return "Greetings from Spring Boot poire !";
//	}
	
	@RequestMapping(method=RequestMethod.GET, value = "/poires2/{userId}", produces = MediaType.APPLICATION_JSON_VALUE)
	public PoireDTO findPoire2ById(@PathVariable Long userId){
	  return poireService.findPoireById(userId);
	}
	
	@GetMapping(value = "/")
	public ResponseEntity<String> pong() 
    {
        logger.info("Démarrage des services OK .....");
        return new ResponseEntity<String>("Réponse du serveur: "+HttpStatus.OK.name(), HttpStatus.OK);
    }
	
	@GetMapping("/poire/{poireId}")
	public PoireDTO findPoireById (@PathVariable Long poireId){
	  return poireService.findPoireById(poireId);
	}
	
	
	
//	@GetMapping(value = "/poires")
//	// http://localhost:8080/poire/poires/
//	public ResponseEntity<List<PoireDTO>> getAllPoires() {
//		List<PoireDTO> users = poireService.getAllPoires();
//		return new ResponseEntity<List<PoireDTO>>(users, HttpStatus.FOUND);
//	}

	
	@GetMapping(value = "/poires")
	// http://localhost:8080/poire/poires/
	public List<PoireDTO> getAllPoires() {
		List<PoireDTO> users = poireService.getAllPoires();
		return users;
	}
	
	@RequestMapping(value= "/wadl", method = RequestMethod.GET, produces = MediaType.TEXT_XML_VALUE)
	public String wadl() throws IOException {
		InputStream wadl = getClass().getResourceAsStream("/application.wadl");
		BufferedReader reader = new BufferedReader(new InputStreamReader(wadl));
		String data="";
		String line;
		while ((line=reader.readLine()) != null) {
			data+=line+"\n";
		}
		return data;
	}

}