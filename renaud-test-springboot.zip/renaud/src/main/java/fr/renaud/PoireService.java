package fr.renaud;

import java.util.ArrayList;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Service
public class PoireService implements IPoireService {

	@Autowired
	private PoireDAO poireDAO;
	@Override
	public List<String> findAll() {
		//var cities = (List<City>) repository.findAll();
		List<Poire> poires=(List<Poire>) poireDAO.findAll();
		List<String> poiresString = new ArrayList<String>();
		for (Poire poire : poires) {
			poiresString.add(poire.getSaison());
		}
		return poiresString;
	}
	public PoireDTO findPoireById(Long poireId) {
		Poire one = poireDAO.getOne(poireId);
		PoireDTO poireDTO=new PoireDTO(one.getId(),one.getSaison());
		return poireDTO;
	}
	
	@Transactional(propagation = Propagation.REQUIRED, readOnly=true)
	public List<PoireDTO> getAllPoires() {
		List<Poire> poires=(List<Poire>) poireDAO.findAll();
		List<PoireDTO> poiresDTO = new ArrayList<PoireDTO>();
		for (Poire poire : poires) {
			poiresDTO.add(new PoireDTO(poire.getId(), poire.getSaison()));
		}
		return poiresDTO;
	}

}
