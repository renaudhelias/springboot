package fr.renaud;

public class PoireDTO {

	long id;
	
	String saison;
	
	public PoireDTO(long id,String saison) {
		this.id=id;
		this.saison=saison;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getSaison() {
		return saison;
	}

	public void setSaison(String saison) {
		this.saison = saison;
	}
	
}
