package fr.renaud;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

@Component
public class ShowBeanList implements CommandLineRunner {

	@Autowired
	ApplicationContext ctx;
	
	@Autowired
	IPoireService poireService;
	
	@Override
	public void run(String... args) throws Exception {
		System.out.println("Listons les beans de Spring Boot :");

		String[] beanNames = ctx.getBeanDefinitionNames();
		Arrays.sort(beanNames);
		for (String beanName : beanNames) {
			System.out.println(beanName);
		}
		
		List<String> poires = poireService.findAll();
		for (String poire : poires) {
			System.out.println("poire : "+poire);
		}
	}

}
